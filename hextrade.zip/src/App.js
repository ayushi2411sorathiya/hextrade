import React, { useEffect } from 'react';
import { Route, Routes } from 'react-router-dom';
import './App.css';
import 'bootstrap/dist/css/bootstrap.css';
import 'bootstrap/dist/css/bootstrap-grid.css';
import 'bootstrap/dist/js/bootstrap.bundle.js';
import Topbar from './jsx/pages/header/Topbar';
import Header from './jsx/pages/header/Header';
import SliderSection from './jsx/components/dashboard/Slider';
import About from './jsx/components/dashboard/About';
import AOS from 'aos';
import 'aos/dist/aos.css';
import InfoSection from './jsx/components/dashboard/InfoSection';
import Home from './jsx/components/dashboard/Home';
import FooterSection from './jsx/pages/footer/FooterSection';
import Contact from './jsx/components/dashboard/Contact';

const App = () => {

  useEffect(() => {
    AOS.init({
      duration: 800, // Duration of the animations in milliseconds
      delay: 100, // Delay before the animation starts
      offset: 120, // Offset from the trigger point to start animations
      once: false, // Animation occurs only once when true, or on every scroll when false
      mirror: false // Mirror animations when scrolling back up
    });
  }, []);
  return (
    <div className='App'>
      {/* Right Bottom Arrow */}
      <div class="aero-container">
        <div class="aero-main">
          <a class="aero-part" href="#home">⬆</a>
        </div>
      </div>

      {/* https://api.whatsapp.com/send/?phone=9265540856 */}

      <Topbar />
      <Header />
      <Routes>
        <Route path="/" exact element={<Home />} />
        <Route path="/contact" exact element={<Contact />} />
      </Routes>
     
      <FooterSection />
    </div>
  )
}

export default App;
