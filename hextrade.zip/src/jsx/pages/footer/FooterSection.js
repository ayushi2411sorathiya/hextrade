import React from 'react';
import {
    FaWhatsapp,
    FaInstagram,
    FaTwitter,
    FaFacebook,
    FaPinterest
} from 'react-icons/fa';

const FooterSection = () => {
    return (
        <div className='container-fluid footer'>
            <div className="container">
                <footer className=" row">
                    <div className="footer-section col-12 col-md-6 col-lg-4">
                        <div className="sub-heading about-heading">
                            <h2 className='fs-4'>CONTACT ADDRESS</h2>
                        </div>
                        <p>India Office No. 01/007 Gayatri Apartment, Opp. Ghatlodiya Police Station, Sola Road, Ahmadabad – 380063, Gujarat, +91 84860 30124, 8401717183 vrundawan-ahd@gmail.com vrundawan.info@gmail.com</p>
                        <div className="social-icons">
                            <a href="https://wa.me/+918486030124" className="social-icon">
                                <FaWhatsapp />
                            </a>
                            <a href="https://www.instagram.com" className="social-icon">
                                <FaInstagram />
                            </a>
                            <a href="https://www.twitter.com" className="social-icon">
                                <FaTwitter />
                            </a>
                            <a href="https://www.facebook.com" className="social-icon">
                                <FaFacebook />
                            </a>
                            <a href="https://www.pinterest.com" className="social-icon">
                                <FaPinterest />
                            </a>
                        </div>

                    </div>
                    <div className='col-1'></div>
                    <div className="footer-section col-12 col-md-6 col-lg-3">
                        <div className="sub-heading about-heading">
                            <h2 className='fs-4'>USEFUL LINKS</h2>
                        </div>
                        <ul>
                            <li className='mb-3'> <a href="" className='footer-item'>Home</a></li>
                            <li className='mb-3'> <a href="" className='footer-item'>About Us</a></li>
                            <li className='mb-3'> <a href="" className='footer-item'>Our Products </a> </li>
                            <li className='mb-3'> <a href="" className='footer-item'>Services</a></li>
                            <li className='mb-3'> <a href="" className='footer-item'>Photo Gallery </a> </li>
                            <li className='mb-3'> <a href="" className='footer-item'>Contact Us</a> </li>
                        </ul>
                    </div>
                    <div className="footer-section col-12 col-md-6 col-lg-4">
                        <div className="sub-heading about-heading">
                            <h2 className='fs-4'>ENQUIRY FORM</h2>
                        </div>
                        <form>
                            <input type="text" placeholder="Name" />
                            <input type="text" placeholder="Mobile Number" />
                            <input type="email" placeholder="Enter email address" />
                            <textarea placeholder="Message"></textarea>
                            <button type="submit">Submit</button>
                        </form>
                    </div>
                    <div className="footer-bottom">
                        <p className='text-center mb-0 my-2'>Copyright ©2024 Hextrade. All Rights reserved.</p>
                    </div>
                </footer>
            </div>
        </div>
    )
}

export default FooterSection